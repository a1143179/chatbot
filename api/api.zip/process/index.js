import fetch from 'node-fetch';
import { logAIInteraction } from '../database.js';

export default async function (context, req) {
    const startTime = Date.now();
    const requestDateTime = new Date();
    
    context.log('Process function called', { method: req.method, headers: req.headers, body: req.body });
    
    // Let Azure Functions handle CORS globally via host.json configuration
    
    // Let Azure Functions handle CORS preflight requests globally
    // Remove explicit OPTIONS handling to avoid conflicts
    
    // Validate request method
    if (req.method !== 'POST') {
        context.log.warn('Invalid method', { method: req.method });
        context.res = {
            status: 405,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
            },
            body: {
                error: 'Method not allowed',
                message: 'Only POST method is supported'
            }
        };
        return;
    }
    
    // Get request body
    const body = req.body;
    context.log('Request body details', { type: typeof body, body: body });
    
    // Validate request body
    if (!body || typeof body !== 'object') {
        context.log.warn('Invalid request body', { body: body });
        context.res = {
            status: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
            },
            body: {
                error: 'Invalid request body',
                message: 'Request body must be a JSON object'
            }
        };
        return;
    }
    
    const { prompt, chatHistory = [], language = 'english' } = body;
    context.log('Request parameters extracted', { 
        prompt: prompt, 
        chatHistoryLength: chatHistory.length, 
        language: language 
    });
    
    // Get environment variable for Google AI API key
    const apiKey = process.env.GOOGLE_AI_API_KEY;
    context.log('API key status', { configured: !!apiKey });
    
    if (!apiKey) {
        context.log.error('Google AI API key not configured');
        context.res = {
            status: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
            },
            body: {
                error: 'Google AI API key not configured',
                message: 'Please configure GOOGLE_AI_API_KEY environment variable in Azure portal'
            }
        };
        return;
    }
    
    if (!prompt || typeof prompt !== 'string' || prompt.trim() === '') {
        context.log.warn('Missing or invalid prompt', { prompt: prompt });
        context.res = {
            status: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
            },
            body: {
                error: 'Missing or invalid prompt parameter',
                message: 'Please provide a valid prompt parameter as a string'
            }
        };
        return;
    }
    
    // Prepare interaction data for logging
    const interactionData = {
        // user_id: req.headers['x-user-id'] || 'anonymous',
        session_id: req.headers['x-session-id'] || null,
        request_datetime: requestDateTime,
        user_prompt: prompt,
        language_preference: language,
        chat_history_count: chatHistory.length,
        request_ip: req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || 'unknown',
        user_agent: req.headers['user-agent'] || 'unknown',
        request_headers: req.headers,
        
    };
    
    try {
        context.log('Calling Google AI API', { prompt: prompt });
        
        // Build conversation history for context
        const contents = [];
        
        // Add conversation history if provided
        if (chatHistory && chatHistory.length > 0) {
            chatHistory.forEach(message => {
                contents.push({
                    role: message.role === 'user' ? 'user' : 'model',
                    parts: [{ text: message.content }]
                });
            });
        }
        
        // Add current user message
        contents.push({
            role: 'user',
            parts: [{ text: prompt }]
        });
        
        context.log('Sending conversation to Google AI', { messageCount: contents.length });
        
        // Create system instruction based on language preference
        const systemInstruction = language === 'chinese' 
            ? "你是一个友好的AI助手。请始终用中文回复用户的问题。保持友好、自然和有趣的对话风格。回复要简洁，适合语音播放。"
            : "You are a friendly AI assistant. Please always respond in English to user questions. Maintain a friendly, natural, and interesting conversation style. Keep responses concise and suitable for voice playback.";
        
        // Update interaction data with system instruction
        interactionData.system_instruction = systemInstruction;
        
        // Call Google AI Studio API
        const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-goog-api-key': apiKey
            },
            body: JSON.stringify({
                contents: contents,
                systemInstruction: {
                    parts: [{ text: systemInstruction }]
                },
                generationConfig: {
                    temperature: 0.7,
                    maxOutputTokens: 150,
                    topP: 0.8,
                    topK: 40
                },
                tools: [
                    {
                        functionDeclarations: [
                            {
                                name: "get_weather",
                                description: "Get real-time weather information for a specific location",
                                parameters: {
                                    type: "OBJECT",
                                    properties: {
                                        location: {
                                            type: "STRING",
                                            description: "City name or location (e.g., 'Beijing', 'New York', 'Tokyo')"
                                        }
                                    },
                                    required: ["location"]
                                }
                            }
                        ]
                    }
                ]
            })
        });
        
        context.log('Google AI API response received', { status: response.status });
        
        if (!response.ok) {
            const errorData = await response.text();
            context.log.error('Google AI API error response', { errorData: errorData });
            throw new Error(`Google AI API error: ${response.status} - ${errorData}`);
        }
        
        const data = await response.json();
        context.log('Google AI API response data', { data: data });
        
        if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
            throw new Error('Invalid response format from Google AI API');
        }
        
        const aiResponse = data.candidates[0].content.parts[0].text;
        context.log('AI response generated', { response: aiResponse });
        
        // Update interaction data with response
        interactionData.ai_response = aiResponse;
        interactionData.response_model = 'gemini-2.0-flash';
        interactionData.response_tokens = aiResponse.length; // Approximate token count
        interactionData.response_time_ms = Date.now() - startTime;
        interactionData.response_datetime = new Date();
        
        // Check if AI wants to call weather function
        if (data.candidates[0].content.parts[0].functionCall) {
            const functionCall = data.candidates[0].content.parts[0].functionCall;
            if (functionCall.name === 'get_weather') {
                const args = functionCall.args;
                const location = args.location;
                
                context.log('Weather function called', { location: location });
                
                // Update interaction data with function call
                interactionData.function_called = 'get_weather';
                interactionData.function_args = args;
                
                // Call weather API (you'll need to add your weather API key)
                const weatherApiKey = process.env.WEATHER_API_KEY;
                if (weatherApiKey) {
                    try {
                        const weatherResponse = await fetch(
                            `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&appid=${weatherApiKey}&units=metric&lang=${language === 'chinese' ? 'zh_cn' : 'en'}`
                        );
                        
                        if (weatherResponse.ok) {
                            const weatherData = await weatherResponse.json();
                            const weatherInfo = language === 'chinese' 
                                ? `${location}的天气：温度${weatherData.main.temp}°C，${weatherData.weather[0].description}，湿度${weatherData.main.humidity}%`
                                : `Weather in ${location}: ${weatherData.main.temp}°C, ${weatherData.weather[0].description}, humidity ${weatherData.main.humidity}%`;
                            
                            context.log('Weather info retrieved', { weatherInfo: weatherInfo });
                            
                            // Update interaction data with function result
                            interactionData.function_result = weatherInfo;
                            interactionData.ai_response = weatherInfo;
                            
                            // Log interaction to database
                            await logAIInteraction(interactionData);
                            
                            context.res = {
                                status: 200,
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*',
                                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                                    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
                                },
                                body: {
                                    response: weatherInfo,
                                    timestamp: new Date().toISOString(),
                                    model: 'gemini-pro',
                                    weatherData: weatherData
                                }
                            };
                            return;
                        }
                    } catch (weatherError) {
                        context.log.error('Weather API error', { error: weatherError.message });
                        interactionData.error_occurred = true;
                        interactionData.error_message = weatherError.message;
                        interactionData.error_type = 'weather_api_error';
                    }
                }
            }
        }
        
        // Log interaction to database
        await logAIInteraction(interactionData);
        
        // Return response
        context.res = {
            status: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
            },
            body: {
                response: aiResponse,
                timestamp: new Date().toISOString(),
                model: 'gemini-pro'
            }
        };
        
    } catch (error) {
        context.log.error('Error processing with Google AI', { error: error.message });
        
        // Update interaction data with error
        interactionData.error_occurred = true;
        interactionData.error_message = error.message;
        interactionData.error_type = 'ai_processing_error';
        interactionData.response_time_ms = Date.now() - startTime;
        interactionData.response_datetime = new Date();
        
        // Log error interaction to database
        await logAIInteraction(interactionData);
        
        context.res = {
            status: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Origin, Accept'
            },
            body: {
                error: 'Error occurred while processing request',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };
    }
} 